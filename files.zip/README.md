# Language Translation Tool 🌍

A professional, production-ready language translation web application built with modern web technologies. Translate text instantly between 26+ languages using the free LibreTranslate API.

## ✨ Features

- 🚀 **Fast & Responsive**: Instant translation with smooth animations
- 🌐 **26+ Languages**: Support for major world languages
- 📋 **Copy to Clipboard**: Quick copy button for translated text
- 🔄 **Language Swap**: Easily swap source and target languages
- 🎨 **Modern UI**: Beautiful glassmorphism design with smooth animations
- 📱 **Mobile Ready**: Fully responsive on all devices
- ⚡ **Performance**: Built with Next.js 14 for optimal performance
- 🎯 **Character Counter**: Track character and word count
- 🔒 **Privacy**: No data storage, all translations are temporary
- ♿ **Accessible**: WCAG compliant interface

## 🛠 Technologies Used

### Frontend
- **Next.js 14** - React framework with App Router
- **React 18** - UI library
- **Tailwind CSS** - Utility-first CSS framework
- **Framer Motion** - Animation library
- **Lucide Icons** - Icon library

### API
- **LibreTranslate** - Free, open-source translation API

### Development Tools
- **TypeScript** - Type safety
- **ESLint** - Code quality
- **PostCSS** - CSS processing

## 📋 Prerequisites

- Node.js 18+ or higher
- npm or yarn package manager
- Git (for version control)

## 🚀 Installation

### Step 1: Clone the Repository

```bash
git clone https://github.com/yourusername/language-translation-tool.git
cd language-translation-tool
```

### Step 2: Install Dependencies

```bash
npm install
# or
yarn install
```

### Step 3: Configure Environment Variables

Copy the example environment file and configure it:

```bash
cp .env.example .env.local
```

Edit `.env.local` (optional - the app works with defaults):

```env
# LibreTranslate API Configuration (optional)
NEXT_PUBLIC_LIBRETRANSLATE_API_URL=https://libretranslate.de
NEXT_PUBLIC_LIBRETRANSLATE_API_KEY=
```

## 💻 Running Locally

### Development Server

```bash
npm run dev
# or
yarn dev
```

The application will start at `http://localhost:3000`

### Production Build

```bash
npm run build
npm run start
```

## 📦 Project Structure

```
language-translation-tool/
├── src/
│   ├── app/                    # Next.js app directory
│   │   ├── layout.tsx         # Root layout with metadata
│   │   └── page.tsx           # Home page
│   ├── components/             # Reusable React components
│   │   ├── Button.tsx         # Reusable button component
│   │   ├── LanguageSelector.tsx
│   │   ├── TextArea.tsx
│   │   ├── TranslationCard.tsx # Main translation interface
│   │   ├── LoadingSpinner.tsx
│   │   ├── ErrorAlert.tsx
│   │   ├── SuccessToast.tsx
│   │   └── Layout.tsx         # App layout wrapper
│   ├── services/               # API services
│   │   └── translationService.ts
│   ├── hooks/                  # Custom React hooks
│   │   └── useTranslation.ts
│   ├── utils/                  # Utility functions
│   │   └── index.ts
│   ├── constants/              # App constants
│   │   └── index.ts
│   ├── types/                  # TypeScript types
│   │   └── index.ts
│   └── styles/                 # Global styles
│       └── globals.css
├── public/                      # Static assets
├── .env.example                # Environment variables template
├── .gitignore                  # Git ignore file
├── .eslintrc.json             # ESLint configuration
├── package.json               # Dependencies and scripts
├── next.config.js             # Next.js configuration
├── tsconfig.json              # TypeScript configuration
├── tailwind.config.js         # Tailwind CSS configuration
├── postcss.config.js          # PostCSS configuration
└── README.md                  # This file
```

## 🔑 Environment Variables

### Available Variables

```env
# LibreTranslate API URL (optional)
NEXT_PUBLIC_LIBRETRANSLATE_API_URL=https://libretranslate.de

# LibreTranslate API Key (optional - only if using self-hosted or premium)
NEXT_PUBLIC_LIBRETRANSLATE_API_KEY=
```

### Getting API Keys

#### Using Free Public API (Recommended)
The application uses the free public LibreTranslate API by default. No API key is required.

- **URL**: `https://libretranslate.de`
- **Limits**: Rate limited, ~30 requests/minute
- **No setup needed** - works out of the box

#### Using Self-Hosted LibreTranslate (Advanced)
For higher request limits, self-host LibreTranslate:

1. Install LibreTranslate: `docker run -d -p 5000:5000 libretranslate/libretranslate`
2. Set `NEXT_PUBLIC_LIBRETRANSLATE_API_URL=http://localhost:5000` in `.env.local`

## 🚢 Deployment

### Deploy to Vercel (Recommended)

1. **Push to GitHub**
   ```bash
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/yourusername/language-translation-tool.git
   git push -u origin main
   ```

2. **Deploy on Vercel**
   - Go to [vercel.com](https://vercel.com)
   - Click "New Project"
   - Select your GitHub repository
   - Click "Deploy"
   - Your app is live! 🎉

3. **Configure Environment Variables on Vercel**
   - Go to Project Settings → Environment Variables
   - Add `NEXT_PUBLIC_LIBRETRANSLATE_API_URL` (optional)
   - Add `NEXT_PUBLIC_LIBRETRANSLATE_API_KEY` (optional)
   - Redeploy

### Deploy to Netlify

1. **Connect GitHub**
   - Go to [netlify.com](https://netlify.com)
   - Click "New Site from Git"
   - Select your GitHub repository

2. **Configure Build Settings**
   - Build command: `npm run build`
   - Publish directory: `.next`

3. **Deploy**
   - Click "Deploy site"

### Deploy to Render

1. **Connect Repository**
   - Go to [render.com](https://render.com)
   - Click "New Web Service"
   - Connect your GitHub repository

2. **Configure**
   - Environment: Node
   - Build command: `npm install && npm run build`
   - Start command: `npm start`
   - Click "Create Web Service"

## 🔄 API Workflow

### Translation Flow

1. User enters text in source language
2. Selects target language
3. Clicks "Translate" button
4. Frontend sends request to LibreTranslate API
5. API returns translated text
6. Result displays in output area
7. User can copy or modify

### Error Handling

- Network errors → User-friendly message
- API timeout → Auto-retry notification
- Invalid language → Graceful fallback
- Empty input → Clear validation message

## 📊 Performance Optimizations

- **Code Splitting**: Automatic with Next.js
- **Image Optimization**: Tailwind CSS for efficient styling
- **API Caching**: Smart request deduplication
- **Lazy Loading**: Components load as needed
- **Memoization**: React hooks prevent unnecessary re-renders

## ♿ Accessibility

- **WCAG 2.1 Compliant**: Level AA standards
- **Keyboard Navigation**: Full keyboard support
- **Screen Reader Friendly**: Proper ARIA labels
- **Color Contrast**: Meets accessibility standards
- **Responsive Design**: Works on all screen sizes

## 🐛 Troubleshooting

### API Connection Issues

```
Error: "Network error. Please check your connection."
```

**Solution:**
1. Check internet connection
2. Verify `NEXT_PUBLIC_LIBRETRANSLATE_API_URL` in `.env.local`
3. Try using the default public API

### Build Errors

```
Error: "Module not found"
```

**Solution:**
```bash
rm -rf node_modules package-lock.json
npm install
```

### Port Already in Use

```bash
# Kill process on port 3000
lsof -ti:3000 | xargs kill -9

# Or use different port
npm run dev -- -p 3001
```

## 🚀 Optimization Tips

### For Faster Translations
- Use LibreTranslate self-hosted version
- Request API key from LibreTranslate for higher limits

### For Better Performance
- Enable caching headers on your server
- Use a CDN for static assets
- Optimize database queries (if added)

## 📈 Future Improvements

- [ ] Translation history with localStorage
- [ ] Favorite translations
- [ ] Dark mode toggle
- [ ] Speech-to-text input
- [ ] Text-to-speech output
- [ ] Batch translation
- [ ] Export to PDF/TXT
- [ ] Multiple translation providers
- [ ] User accounts and cloud sync
- [ ] AI-powered context-aware translation
- [ ] Real-time collaboration
- [ ] Custom glossary support

## 📝 Code Quality Standards

### Clean Code Principles
- ✅ Single Responsibility Principle
- ✅ DRY (Don't Repeat Yourself)
- ✅ Proper Error Handling
- ✅ Meaningful Variable Names
- ✅ Well-Documented Functions

### TypeScript Best Practices
- ✅ Strict mode enabled
- ✅ Proper type definitions
- ✅ No `any` types
- ✅ Exhaustive type checking

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## 📞 Support

For support, email support@example.com or open an issue on GitHub.

## 🙏 Acknowledgments

- [LibreTranslate](https://github.com/LibreTranslate/LibreTranslate) - Translation API
- [Next.js](https://nextjs.org/) - React Framework
- [Tailwind CSS](https://tailwindcss.com/) - CSS Framework
- [Framer Motion](https://www.framer.com/motion/) - Animation Library

---

**Built with ❤️ by Your Name | [GitHub](https://github.com/yourusername) | [Twitter](https://twitter.com/yourhandle)**

Made for internship submission - Demonstrating professional full-stack development practices.
