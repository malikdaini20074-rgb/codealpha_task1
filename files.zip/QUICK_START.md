# Quick Start Guide ⚡

Get the Language Translation Tool running in 5 minutes.

## Prerequisites

- Node.js 18+
- npm or yarn
- Git

## Installation (2 minutes)

```bash
# 1. Clone the repository
git clone https://github.com/yourusername/language-translation-tool.git
cd language-translation-tool

# 2. Install dependencies
npm install

# 3. Copy environment file
cp .env.example .env.local

# Done! ✅
```

## Run Locally (1 minute)

```bash
npm run dev
```

Open `http://localhost:3000` in your browser.

## Deploy to Vercel (1 minute)

1. Push code to GitHub
2. Go to [vercel.com](https://vercel.com)
3. Click "New Project"
4. Select your repository
5. Click "Deploy"

Your app is live! 🎉

## Features Ready to Use

- ✅ 26+ language support
- ✅ Copy translation button
- ✅ Language swap
- ✅ Character counter
- ✅ Beautiful UI
- ✅ Mobile responsive
- ✅ Dark mode ready

## Keyboard Shortcuts

| Shortcut | Action |
|----------|--------|
| `Enter` | Translate (with Cmd/Ctrl) |
| `Tab` | Navigate between fields |
| `Escape` | Clear input |

## API Configuration (Optional)

The app works with the free public LibreTranslate API by default.

To use your own API:

```bash
# Edit .env.local
NEXT_PUBLIC_LIBRETRANSLATE_API_URL=your-api-url
NEXT_PUBLIC_LIBRETRANSLATE_API_KEY=your-api-key
```

Then run:
```bash
npm run dev
```

## Build for Production

```bash
npm run build
npm start
```

## Project Structure

```
src/
├── app/           # Next.js pages
├── components/    # React components
├── services/      # API calls
├── hooks/         # Custom hooks
├── utils/         # Utilities
├── constants/     # Constants
└── types/         # TypeScript types
```

## Common Issues

### Port 3000 Already in Use
```bash
npm run dev -- -p 3001
```

### Module Not Found
```bash
rm -rf node_modules
npm install
```

### API Not Working
- Check internet connection
- Verify `.env.local` file
- Ensure `NEXT_PUBLIC_LIBRETRANSLATE_API_URL` is set

## Next Steps

1. **Customize**: Edit colors in `tailwind.config.js`
2. **Deploy**: Follow [DEPLOYMENT.md](./DEPLOYMENT.md)
3. **Contribute**: See [CONTRIBUTING.md](./CONTRIBUTING.md)
4. **Learn**: Check [README.md](./README.md) for full docs

## Support

- 📖 Full documentation: [README.md](./README.md)
- 🚀 Deployment guide: [DEPLOYMENT.md](./DEPLOYMENT.md)
- 🤝 Contributing: [CONTRIBUTING.md](./CONTRIBUTING.md)
- 🐛 Issues: [GitHub Issues](https://github.com/yourusername/language-translation-tool/issues)

---

**Need help?** Check the FAQ section below.

## FAQ

**Q: Can I use this for production?**
A: Yes! It's production-ready and follows senior-level coding standards.

**Q: Is it free to use?**
A: Yes! Uses free LibreTranslate API. No API key required.

**Q: Can I modify it?**
A: Yes! It's MIT licensed. Do whatever you want.

**Q: How do I add more languages?**
A: Edit `src/constants/index.ts` and add language codes.

**Q: Can I self-host the API?**
A: Yes! Docker container available at [LibreTranslate GitHub](https://github.com/LibreTranslate/LibreTranslate)

**Q: How do I monetize it?**
A: Host your own API, add premium features, or sell API access.

---

**Happy translating! 🌍**
