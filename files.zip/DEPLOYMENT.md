# Deployment Guide 🚀

Complete step-by-step guide to deploy the Language Translation Tool to production.

## Table of Contents

1. [Pre-Deployment Checklist](#pre-deployment-checklist)
2. [Vercel Deployment](#vercel-deployment-recommended)
3. [Netlify Deployment](#netlify-deployment)
4. [Render Deployment](#render-deployment)
5. [Docker Deployment](#docker-deployment)
6. [GitHub Pages](#github-pages)
7. [Post-Deployment](#post-deployment)

---

## Pre-Deployment Checklist

Before deploying, ensure:

- [ ] All code is committed and pushed to GitHub
- [ ] `.env.example` is updated with all required variables
- [ ] Sensitive data is NOT hardcoded in the repository
- [ ] Build completes without errors: `npm run build`
- [ ] Application works locally: `npm run dev`
- [ ] All tests pass (if applicable)
- [ ] README.md is comprehensive and accurate
- [ ] License is included (MIT or your choice)

## Vercel Deployment (Recommended) ⭐

Vercel is the official Next.js hosting platform with zero-config deployment.

### Step 1: Prepare Your Repository

```bash
# Ensure all changes are committed
git add .
git commit -m "Final pre-deployment commit"
git push origin main
```

### Step 2: Sign Up / Log In to Vercel

- Go to [vercel.com](https://vercel.com)
- Click "Sign Up"
- Choose "Continue with GitHub"
- Authorize Vercel to access your GitHub account

### Step 3: Import Your Project

1. Click "Add New..." → "Project"
2. Select your `language-translation-tool` repository
3. Click "Import"

### Step 4: Configure Project

The default settings should work fine:

- **Framework Preset**: Next.js ✓
- **Build Command**: `npm run build` ✓
- **Output Directory**: `.next` ✓
- **Install Command**: `npm install` ✓

### Step 5: Environment Variables

1. Click "Environment Variables" section
2. Add variables:

```
NEXT_PUBLIC_LIBRETRANSLATE_API_URL=https://libretranslate.de
NEXT_PUBLIC_LIBRETRANSLATE_API_KEY= (leave empty if using free API)
```

3. Click "Add"
4. Select environments: Production, Preview, Development
5. Click "Save"

### Step 6: Deploy

Click "Deploy" button. Vercel will:

1. Build your Next.js application
2. Optimize for production
3. Deploy to global edge network
4. Provide you with a live URL

### Step 7: Verify Deployment

- Check the deployment logs for errors
- Visit the provided URL
- Test the translation functionality

### Bonus: Custom Domain

1. Go to Project Settings → Domains
2. Click "Add Domain"
3. Enter your custom domain
4. Follow DNS configuration instructions
5. Verify ownership
6. Domain is now live!

### Vercel Benefits

✅ Zero-config deployment
✅ Automatic deployments on push
✅ Global CDN
✅ Edge functions support
✅ Preview URLs for every PR
✅ Analytics and monitoring
✅ Free SSL certificate

---

## Netlify Deployment

### Step 1: Connect Repository

1. Go to [netlify.com](https://netlify.com)
2. Click "New Site from Git"
3. Choose GitHub → Select your repository
4. Authorize Netlify

### Step 2: Configure Build Settings

```
Build command:    npm run build
Publish directory: .next
```

### Step 3: Environment Variables

1. Click "Site Settings" → "Build & Deploy"
2. Scroll to "Environment"
3. Click "Edit variables"
4. Add your environment variables:

```
NEXT_PUBLIC_LIBRETRANSLATE_API_URL=https://libretranslate.de
```

5. Save and redeploy

### Step 4: Deploy

- Click "Deploy site"
- Wait for build to complete
- Your site is live!

### Netlify Benefits

✅ Easy GitHub integration
✅ Automatic deployments
✅ Split testing support
✅ Analytics
✅ Forms support
✅ Role-based access control

---

## Render Deployment

### Step 1: Create Account

1. Go to [render.com](https://render.com)
2. Sign up with GitHub
3. Authorize Render

### Step 2: Create New Web Service

1. Click "New +" → "Web Service"
2. Select your repository
3. Click "Connect"

### Step 3: Configure

```
Name: language-translation-tool
Environment: Node
Build Command: npm install && npm run build
Start Command: npm start
```

### Step 4: Environment Variables

1. Scroll to "Environment"
2. Add variables:

```
NEXT_PUBLIC_LIBRETRANSLATE_API_URL=https://libretranslate.de
NEXT_PUBLIC_LIBRETRANSLATE_API_KEY=
```

3. Click "Create Web Service"

### Step 5: Monitor

- Watch the build logs
- Once deployed, visit your URL
- Test functionality

---

## Docker Deployment

For self-hosted or containerized deployment.

### Step 1: Create Dockerfile

```dockerfile
# Build stage
FROM node:18-alpine as builder

WORKDIR /app

# Copy package files
COPY package*.json ./

# Install dependencies
RUN npm ci

# Copy source code
COPY . .

# Build application
RUN npm run build

# Runtime stage
FROM node:18-alpine

WORKDIR /app

# Copy package files
COPY package*.json ./

# Install production dependencies only
RUN npm ci --omit=dev

# Copy built application from builder
COPY --from=builder /app/.next ./.next
COPY --from=builder /app/public ./public

# Expose port
EXPOSE 3000

# Start application
CMD ["npm", "start"]
```

### Step 2: Create .dockerignore

```
node_modules
npm-debug.log
.git
.gitignore
README.md
.next
.env
.env.*
!.env.example
```

### Step 3: Build and Run

```bash
# Build image
docker build -t translation-tool .

# Run container
docker run -e NEXT_PUBLIC_LIBRETRANSLATE_API_URL=https://libretranslate.de \
  -p 3000:3000 \
  translation-tool
```

### Step 4: Deploy to Docker Hub

```bash
# Login to Docker Hub
docker login

# Tag image
docker tag translation-tool yourusername/translation-tool:latest

# Push
docker push yourusername/translation-tool:latest

# Pull and run on any machine
docker run -p 3000:3000 yourusername/translation-tool:latest
```

---

## GitHub Pages Deployment

### Note

GitHub Pages hosts static sites. For Next.js, use static export.

### Step 1: Configure Next.js for Static Export

Edit `next.config.js`:

```javascript
/** @type {import('next').NextConfig} */
const nextConfig = {
  output: 'export',
  reactStrictMode: true,
  swcMinify: true,
}

module.exports = nextConfig
```

### Step 2: Build

```bash
npm run build
```

This creates an `out` directory with static files.

### Step 3: Deploy

```bash
# Install gh-pages
npm install --save-dev gh-pages

# Add to package.json scripts:
# "deploy": "next build && gh-pages -d out"

npm run deploy
```

### Step 4: Configure Repository Settings

1. Go to Settings → Pages
2. Set source to "gh-pages" branch
3. Your site will be live at: `https://yourusername.github.io/language-translation-tool`

---

## Post-Deployment

### Verify Deployment

- [ ] Application loads without errors
- [ ] Translation works correctly
- [ ] All buttons are functional
- [ ] Mobile responsiveness works
- [ ] No console errors
- [ ] Performance is acceptable

### Monitor Application

#### Vercel
- Built-in analytics in dashboard
- Performance monitoring
- Error tracking

#### Netlify
- Analytics dashboard
- Usage statistics
- Function monitoring

#### Custom
- Google Analytics
- Sentry error tracking
- LogRocket monitoring

### Update Domain

```bash
# Update links in:
- README.md
- Package.json (homepage field)
- Open Graph meta tags
- Social media profiles
```

### CI/CD Pipeline

Automatically redeploy on push:

```yaml
# .github/workflows/deploy.yml
name: Deploy

on:
  push:
    branches: [main]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-node@v3
        with:
          node-version: '18'
      - run: npm ci
      - run: npm run build
      - name: Deploy to Vercel
        run: npx vercel --prod --token=${{ secrets.VERCEL_TOKEN }}
```

### Maintenance

- Keep dependencies updated: `npm update`
- Monitor for security vulnerabilities: `npm audit`
- Backup database regularly (if added)
- Monitor error logs
- Track performance metrics

---

## Troubleshooting Deployment

### Build Fails

```bash
# Clear cache and rebuild
rm -rf .next node_modules
npm install
npm run build
```

### Environment Variables Not Working

- Verify variables are set in platform settings
- Check variable names (case-sensitive)
- Redeploy after adding variables
- Prefix public variables with `NEXT_PUBLIC_`

### API Calls Fail After Deploy

- Check CORS settings on API
- Verify API URL is accessible from deployment region
- Add error logging to track issues
- Test API endpoint directly

### Performance Issues

- Check bundle size: `npm install --save-dev @next/bundle-analyzer`
- Enable image optimization
- Use dynamic imports for large components
- Enable caching headers

---

## Deployment Comparison

| Feature | Vercel | Netlify | Render | GitHub Pages |
|---------|--------|---------|--------|--------------|
| **Setup** | Easiest | Easy | Medium | Medium |
| **Cost** | Free tier | Free tier | Free tier | Free |
| **Scaling** | Automatic | Automatic | Manual | Static |
| **Custom Domain** | Yes | Yes | Yes | Yes |
| **Serverless** | Yes | Yes | Yes | No |
| **Analytics** | Yes | Yes | Basic | No |
| **Support** | Excellent | Good | Good | Community |

---

## Next Steps

After deployment:

1. **Monitor Analytics**: Track user behavior and performance
2. **Gather Feedback**: Improve based on user feedback
3. **Scale**: Add more features as demand grows
4. **Monetize**: Consider paid features or API access
5. **Market**: Share on social media and tech communities

---

## Additional Resources

- [Next.js Deployment Docs](https://nextjs.org/docs/deployment)
- [Vercel Documentation](https://vercel.com/docs)
- [Netlify Documentation](https://docs.netlify.com/)
- [Render Docs](https://render.com/docs)
- [Docker Best Practices](https://docs.docker.com/develop/dev-best-practices/)

---

**Need help?** Check deployment logs or contact platform support.

**Happy deploying! 🚀**
